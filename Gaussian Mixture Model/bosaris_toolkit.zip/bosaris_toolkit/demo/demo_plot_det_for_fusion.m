function demo_plot_det_for_fusion(test_data,prior,type)
% Display two systems and their fusion on a DET plot.
% This function is called by 'demo_main'

plot_title = 'DET plot for Image DataSet';
plot_type = Det_Plot.make_plot_window_from_string(type);
plot_obj = Det_Plot(plot_type,plot_title);

plot_obj.set_system(test_data.tar1,test_data.non1,'Diagonal CoV');
plot_obj.plot_steppy_det({'r','LineWidth',3},' ');
%plot_obj.plot_mindcf_point(prior,{'b*','MarkerSize',8},'mindcf');

plot_obj.set_system(test_data.tar2,test_data.non2,'Full CoV');
plot_obj.plot_steppy_det({'g','LineWidth',3},' ');

plot_obj.set_system(test_data.tar3,test_data.non3,'Diagonal CoV - Normalized Dataset');
plot_obj.plot_steppy_det({'b','LineWidth',3},' ');

plot_obj.set_system(test_data.tar4,test_data.non4,'Full CoV - Normalized Dataset');
plot_obj.plot_steppy_det({'y','LineWidth',3},' ');

plot_obj.set_system(test_data.tar5,test_data.non5,'Diagonal CoV - Normalized Individual Class');
plot_obj.plot_steppy_det({'m','LineWidth',3},' ');

plot_obj.set_system(test_data.tar6,test_data.non6,'Full CoV - Normalized Individual Class');
plot_obj.plot_steppy_det({'c','LineWidth',3},' ');

% plot_obj.set_system(test_data.tar_f,test_data.non_f,['Case ',num2str(caseno)]);
% %plot_obj.plot_rocch_det({'g','LineWidth',2},' ');
% plot_obj.plot_steppy_det({'g','LineWidth',2},' ');
% plot_obj.plot_mindcf_point(prior,{'g*','MarkerSize',8},'mindcf');

plot_obj.display_legend();

%fprintf('Look at the figure entitled ''DET plot for fusion'' to see a DET plot with curves for the two systems and their fusion.\n');
